<!--
UNLESS SUBMITTING A PULL REQUEST, PLEASE USE THE APPROPRIATE ISSUE TEMPLATES:

https://github.com/Valve/fingerprintjs2/issues/new?template=fingerprint_changes.md
https://github.com/Valve/fingerprintjs2/issues/new?template=other_bug.md
-->
